# SEON Bundled Android SDK

## Description

SEON Bundled Android SDK is a framework designed to integrate SEON's web-based identity verification capabilities into your Android applications through a native wrapper. This SDK provides a WebView-based solution that loads the SEON Web SDK iframe within your native Android app, offering seamless integration while maintaining the flexibility and features of the web-based verification flow.

**Owner Team:** SEON Technologies Ltd.

## Installation

SEON Bundled Android SDK is available through Maven Central Repository. To install it, follow these steps:

##### If you are using kotlin version catalogs

- Add this into your project level (root) `settings.gradle.kts`:

```
dependencyResolutionManagement {
    repositories {
        ...
        mavenCentral()
    }
}
```
- Add these lines under the proper section in the `libs.versions.toml`:

```
[versions]
...
seonBundledSDK = "0.1.0"
...
[libraries]
...
seon-bundled-android-sdk = { group = "io.seon.idvandroid", name = "bundled-android-sdk", version.ref = "seonBundledSDK" }
```

- And add this into your module level (eg. app) `build.gradle.kts`:

```
dependencies {
    ...
    implementation(libs.seon.bundled.android.sdk)
}
```

- You can now run gradle sync.

------------

##### If you are using older gradle dependency management
*(syntax may be vary for gradle or gradle.kts files)*

- Add this line to the project level (root) `build.gradle(.kts)`:

```
allprojects {
    repositories {
        ...
        mavenCentral()
    }
}
```

- And add this line to the module level (eg. app) `build.gradle(.kts)`:

```
dependencies {
    ...
    implementation "io.seon.idvandroid:bundled-android-sdk:0.1.0"
}
```

- You can now run gradle sync.

------------

## Usage

### 1. Initialize the SDK

First, initialize the SDK through the IDVService class (singleton) initialize(...) method:

```kotlin
IDVService.instance.initialize(
    baseUrl = "https://idv-eu.seon.io", // alternatively: "https://idv-us.seon.io"
    customerData = IDVCustomerData(
        licenseKey = "YOUR_LICENSE_KEY", // use the licenseKey you received from SEON (required)
        referenceId = "UNIQUE_REFERENCE_ID", // Random unique value for the session
                                             // e.g. UUID, or {userID}-{timestamp} (required)
        email = "user@example.com",      // Email input (optional)
        name = "John Doe",               // Name input (optional)
        phoneNumber = "+1234567890",     // Phone number input (optional)
        type = "id-verification",        // Process type (optional)
        userId = "user123",              // Unique user identifier (optional)
        countryISOCode = "US",           // ISO code for the country (optional)
        address = "123 Main St, NY",     // Address input (optional)
        dateOfBirth = IDVDateOfBirth(    // Reference date for the DoB check (optional)
            day = 1,
            month = 1,
            year = 2000
        ),
        postalCode = "12345",            // Reference value for postal check (optional)
        additionalProperties = mapOf(    // Custom key-value pairs (optional)
            "customField1" to "value1",
            "customField2" to "value2"
        )
    ),
    templateId = null,                   // Template ID for customization (optional)
    languageCode = "en",                 // Language code (optional, defaults to "en")
    theme = """{"primaryColor": "#007bff", "backgroundColor": "#ffffff"}""" // JSON theme string (optional)
)
```

### 2. Start Web SDK Flow

Initialize the activity result launcher and start the verification flow:

```kotlin
private val verificationLauncher = registerForActivityResult(
    ActivityResultContracts.StartActivityForResult()
) { result: ActivityResult ->
    val flowResult = result.data?.getSerializableExtra("IDV_FLOW_RESULT") as? IDVFlowResult
    val error = result.data?.getStringExtra("VERIFICATION_ERROR_KEY")
    
    when (flowResult) {
        IDVFlowResult.Completed,
        IDVFlowResult.CompletedSuccess -> {
            // Verification completed successfully
            handleSuccess()
        }
        IDVFlowResult.CompletedFailed -> {
            // Verification failed
            handleFailure()
        }
        IDVFlowResult.CompletedPending -> {
            // Verification pending review
            handlePending()
        }
        IDVFlowResult.InterruptedByUser -> {
            // User cancelled the flow
            handleCancellation()
        }
        IDVFlowResult.Error -> {
            // An error occurred
            handleError(error)
        }
        null -> {
            // No result received
            handleNoResult()
        }
    }
}

// Launch the Web SDK verification flow
IDVService.instance.startWebVerificationFlow(
    verificationLauncher,
    this // context
)
```

### 3. Theming Support

The SDK supports custom theming through a JSON string passed to the `initialize()` method. The theme parameter allows you to customize the appearance of the web SDK:

```kotlin
val customTheme = """
{
    "primaryColor": "#007bff",
    "backgroundColor": "#ffffff",
    "textColor": "#333333",
    "buttonColor": "#28a745",
    "errorColor": "#dc3545"
}
"""

IDVService.instance.initialize(
    baseUrl = "https://idv-eu.seon.io",
    customerData = customerData,
    templateId = null,
    languageCode = "en",
    theme = customTheme  // Pass your custom theme here
)
```

### 4. Key Features

- **WebView Integration**: Loads SEON Web SDK iframe within a native Android WebView
- **Camera Permissions**: Automatically handles camera permissions for inline camera access
- **Cross-Platform Communication**: JavaScript bridge for web-to-native communication
- **Language Support**: Supports multiple languages through language codes and Accept-Language headers
- **Custom Theming**: JSON-based theming system for UI customization
- **Error Handling**: Comprehensive error handling and logging
- **Session Management**: Automatic session loading and URL construction

------------


## Deploy a new version to Maven Central

For publishing the app on Maven Central, you need the login credentials for [Sonatype Portal](https://s01.oss.sonatype.org/). Please reach out to your manager for this information.

After login, Here are the steps:

1. You need these artifacts prepared for the publish:
    - .pom file
    - .aar file
These items by default are getting created upon running build or publish commands using ./gradlew

2. You need to sign the artifacts above to generate .asc artifacts for each of them. You can use command below to generate them:
    - gpg -ab NAME_OF_YOUR_POM_ARTIFACT.pom
    - gpg -ab NAME_OF_YOUR_AAR_ARTIFACT.aar
This will create the required .asc files for you to be used for the publish.

3. On the left side of the Sonatype panel, you should tap on the `Staging Upload` option. At top, you will first select the pom file. On the next section, you should add each of the other 3 artifacts and tap on `Add Artifact` button. Once you have added all remaining artifacts at the lower section and pom file at the top, you need to add a Description to the lower section as well. Something like: `ID Verification SDK for Android vX.X.X` which describes you current build would be sufficient. After that, you should tap on `Upload Artifact(s)` to have them uploaded.

4. After the upload, you should go into `Staging Repositories` and find your uploaded Build. Once the process is done, You should be able to see a `Release` button available at the top. Tapping that will publish your new version to the Released Repositories.

5. Please check if the library with that specific version which you just released is available to you on a sample app, just to make sure that other developers have no problem in accessing that.


## Deploy a new version to Jitpack

- Unless specified otherwise, we are supposed to publish our sdk on the Maven Central Repository. So, by default, please go with the instruction under the section "Deploy a new version to Maven Central"

- Look for "Releases" section to the right panel on the github project/code page, click on the title to navigate

- Click on "Draft a new release" button on the top right section

- Open the "Choose a tag" panel and type your version (1.0.0 {major.minor.patch} format is the most common) to release and click on "+ Create new tag %YOUR_TYPED_VERSION%" or select an existing tag you created before
> IMPORTANT NOTE: this will be the version number what will be used in dependency managers to access the library, so please type/select a proper one

- Select the target branch if necessary (master is selected by default)

- Optionally add a title / description (have no effect in Jitpack) this will be private on your github releases section

- You can mark it as a pre-release if its not a final version (you can update or change whenever you like to)

- You don't have to attach any files here, for Jitpack release nothing is needed

- Click "Publish release"

- Navigate in your browser to the project's Jitpack page (https://jitpack.io/#seontechnologies/id-verification-sdk-android) (you will need access to this page)

- Under the "Releases" tab, the just created version's tag should be visible on the top of the list with a grayish "Get it" button, you should click it to start the Jitpack's build process from the tag, this will take a while and a spinner will be displayed

- Once its done the spinner is not more visible, and if the build succeeded The "Log" button's outline should turn to be green, as well the "Get it" button's background, and the new version is now accessible via the dependency manager

- If it fails the buttons will not turn to green, and you should check the logs for more information

- For development/internal purposes you can build a new version from any of your branches, to do so under the "Branches" tab look for your branch and click the "Get it" button, and that will get the "%BRANCH_NAME%-SNAPSHOT" version tag if you would like to access and download it without a new github release
