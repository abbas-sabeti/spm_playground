# SEON SDK JNI Wrapper - Deployment Guide

## Files Structure
```
seon-sdk-release/
├── libs/
│   ├── arm64-v8a/          # 64-bit ARM (modern devices)
│   │   ├── libseon-sdk.so  # Your JNI wrapper
│   │   ├── libseon.so      # SEON main library
│   │   ├── libnatdet.so    # Native detection
│   │   └── libpgs.so       # Additional component
│   ├── armeabi-v7a/        # 32-bit ARM (older devices)
│   ├── x86/                # 32-bit Intel (emulators)
│   └── x86_64/             # 64-bit Intel (emulators)
├── NativeSdkLoader.java    # Java interface
└── README.md               # Full documentation
```

## Android Integration

### 1. Copy Libraries
Copy the appropriate architecture folder to your Android project:
```
app/src/main/jniLibs/arm64-v8a/libseon-sdk.so
app/src/main/jniLibs/arm64-v8a/libseon.so
app/src/main/jniLibs/arm64-v8a/libnatdet.so
app/src/main/jniLibs/arm64-v8a/libpgs.so
```

### 2. Java Integration
```java
public class NativeSdkLoader {
    static {
        // Load SEON SDK dependencies first
        System.loadLibrary("natdet");
        System.loadLibrary("pgs"); 
        System.loadLibrary("seon");
        
        // Then load your wrapper
        System.loadLibrary("seon-sdk");
    }
    
    // Native methods...
    public static native boolean initializeSeonSdk(String sessionId);
    public static native String startFingerprinting();
    // ... other methods
}
```

### 3. Usage Example
```java
// Initialize
boolean success = NativeSdkLoader.initializeSeonSdk("your-session-id");

// Configure
NativeSdkLoader.setFraudApiUrl("https://api.seon.io");

// Get fingerprint
String fingerprint = NativeSdkLoader.startFingerprinting();

// Cleanup
NativeSdkLoader.clearSeonSdk();
```

## Remote Loading (for POC)

For dynamic loading from remote host:
1. Host the architecture-specific .so files on your server
2. Download them to Android internal storage
3. Use `System.load()` with absolute paths instead of `System.loadLibrary()`

```java
// Load from absolute paths
System.load("/data/data/your.package/files/libnatdet.so");
System.load("/data/data/your.package/files/libpgs.so");
System.load("/data/data/your.package/files/libseon.so");
System.load("/data/data/your.package/files/libseon-sdk.so");
```
