package io.seon.dynamic_sdk_loader;

/**
 * Java interface for the SEON SDK JNI wrapper
 * This class provides the Java interface to load and interact with the native SEON SDK library
 */
public class NativeSdkLoader {
    
    // Load the native library (static linking - single file deployment)
    static {
        try {
            System.loadLibrary("seon-sdk");
        } catch (UnsatisfiedLinkError e) {
            throw new RuntimeException("Failed to load native library: seon-sdk", e);
        }
    }
    
    /**
     * Initialize the SEON SDK with a session ID
     * @param sessionId The session ID to initialize the SDK with
     * @return true if initialization was successful, false otherwise
     */
    public static native boolean initializeSeonSdk(String sessionId);
    
    /**
     * Start the fingerprinting process
     * @return The fingerprint string, or null if fingerprinting failed
     */
    public static native String startFingerprinting();
    
    /**
     * Set the fraud API URL
     * @param url The fraud API URL to set
     * @return true if the URL was set successfully, false otherwise
     */
    public static native boolean setFraudApiUrl(String url);
    
    /**
     * Get the current session ID
     * @return The current session ID, or null if SDK is not initialized
     */
    public static native String getSessionId();
    
    /**
     * Clear and cleanup the SEON SDK
     */
    public static native void clearSeonSdk();
    
    /**
     * Set a configuration parameter for the SEON SDK
     * @param key The configuration key
     * @param value The configuration value
     * @return true if the configuration was set successfully, false otherwise
     */
    public static native boolean setSeonConfig(String key, String value);
    
    /**
     * Example usage of the SEON SDK wrapper
     */
    public static class Example {
        public static void demonstrateUsage() {
            try {
                // Initialize the SDK
                boolean initialized = initializeSeonSdk("example-session-123");
                if (!initialized) {
                    System.err.println("Failed to initialize SEON SDK");
                    return;
                }
                
                // Configure the SDK
                setFraudApiUrl("https://api.seon.io");
                setSeonConfig("timeout", "30000");
                setSeonConfig("retries", "3");
                
                // Get session ID
                String sessionId = getSessionId();
                System.out.println("Current session ID: " + sessionId);
                
                // Start fingerprinting
                String fingerprint = startFingerprinting();
                if (fingerprint != null) {
                    System.out.println("Fingerprint: " + fingerprint);
                } else {
                    System.err.println("Failed to get fingerprint");
                }
                
                // Cleanup
                clearSeonSdk();
                System.out.println("SDK cleanup completed");
                
            } catch (Exception e) {
                System.err.println("Error during SEON SDK usage: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
